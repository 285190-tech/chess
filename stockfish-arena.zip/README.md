# Engine Room — Stockfish vs Stockfish

A static chess match viewer. Stockfish runs locally in a browser worker; no backend is needed.

## Keep these files together

Put all three files in the same repository directory (the repository root is easiest):

- `index.html`
- `stockfish-19-lite-single.js`
- `stockfish-19-lite-single.wasm`

The two Stockfish files are a matched Stockfish.js 19.0.1 lite, single-threaded build. Don't rename them unless you also update the worker path in `index.html`.

## Publish with GitHub Pages

1. Commit the three files to your repository's default branch.
2. Open **Settings → Pages** and publish from the default branch, using `/(root)`.
3. Open the Pages URL. The engine may take a few seconds to initialize on first load.

For local testing, serve the folder over HTTP (for example, `python -m http.server 8000`) rather than opening `index.html` directly. The browser must be able to load the matching WASM file beside the worker. Sandboxed file previews may block browser workers or sibling-file requests; use GitHub Pages or the live web-server preview instead.

## Open-source credits

- Stockfish.js 19.0.1 — GPL-3.0. License text and source links are included in the page.
- chess.js 1.4.0 — MIT. License text and source link are included in the page.
